<script>
   export let inputText = "What is Supdawg?";
</script>
    
<strong>{inputText}</strong>

<style>
	strong {
		color: red;
	}
</style>